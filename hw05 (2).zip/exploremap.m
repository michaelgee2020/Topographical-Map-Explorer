function exploremap(long,lat,elev)
%EXPLOREMAP Creates an interactive map to explore
% This function will take in the data given by the three arrays, X, Y, and
% Z. They must all be arrays of the same dimensions. It will then plot the
% contour map and a surface map and will allow the user to move about the
% contour map using the WASD keys. The user will quit using the Q key. The
% boundary box should not extend beyond the map edges
% INPUTS
% LONG - Numeric array containing longitude values
% LAT - Numeric array containing latitude values
% ELEV - Numeric array containing elevation values

%% TODO: WRITE CODE HERE

%% don't touch this stuff
set(gcf,'KeyPressFcn',@callback);
set(gcf,'CurrentCharacter','n');
choose = 'n';
while (choose ~= 'q')
    choose = get(gcf,'CurrentCharacter');
    switch choose
        case 's' %the user wants to move south
            %% TODO: WRITE CODE HERE
            
            %% stop writing code here
        case 'w' %the user wants to move north
            %% TODO: WRITE CODE HERE
            
            %% stop writing code here
        case 'a' %the user wants to move west
            %% TODO: WRITE CODE HERE
            
            %% stop writing code here
        case 'd' %the user wants to move east
            %% TODO: WRITE CODE HERE
            
            %% stop writing code here

    end
    set(gcf,'CurrentCharacter','n');
    %% TODO: WRITE CODE HERE
    
    %% stop writing code here
    pause(0.1);
    
end
end

%% don't touch any of this.
function callback(hObject, callbackdata)

end